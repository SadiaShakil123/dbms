﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBMS
{
    public partial class doctorLogin : Form
    {
        List<string> diseaselist = new List<string>();
        List<string> priscriptionList = new List<string>();
        int flag = 0;
        int flagold = 0;
        int flagnew = 0;
        int pflag = 0;
        int pflagold = 0;
        int pflagnew = 0;
        public doctorLogin()
        {
            InitializeComponent();
            panel4.Show();
            panel6.Hide();
            comboBox4.Hide();
            fillcomboCnic(comboBox2);
            bunifuFlatButton3.Hide();
            fillcombodisease(comboBox4);
            fillComboPrescription(comboBox6);
            bunifuThinButton21.Hide();
            bunifuThinButton22.Hide();
            comboBox9.Items.Clear();
            fillcomboCnicOut();
            comboBox5.Hide();
            comboBox7.Hide();
            label14.Hide();
            label16.Hide();
            label15.Hide();
            textBox5.Hide();
            button7.Hide();
            comboBox6.Hide();
        }
        public void fillThatBox(ComboBox c, int id)
        {
            string cnic = null;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.Patient";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                if (int.Parse(reader["P_Id"].ToString()) == id)
                {
                    cnic = (reader["P_CNIC"].ToString());
                    c.Items.Add(cnic);
                    break;
                }
            }
            conn.Close();
        }
        public void fillcomboCnicOut()
        {
            int ID = 0;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.AdmittedPatient";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ID = int.Parse(reader["p_id"].ToString());
                fillThatBox(comboBox9, ID);
            }
            conn.Close();
        }
        public void fillComboBed()
        {
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.Bed";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                if (int.Parse(reader["ward_Id"].ToString()) == getWardId(comboBox5))
                {
                    if (reader["Bed_Status"].ToString() == "free")
                    {
                        string add = "Bed-" + reader["Bed_Id"].ToString();
                        comboBox7.Items.Add(add);
                    }
                }
            }
            conn.Close();
        }
        public void fillComboWard(ComboBox c)
        {
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.wards";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string add = reader["WardName"].ToString();
                c.Items.Add(add);
            }
            conn.Close();
        }
        public void fillComboPrescription(ComboBox c)
        {
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.priscription";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string add = reader["prisccriptionName"].ToString();
                c.Items.Add(add);
            }
            conn.Close();
        }
        public void fillcomboCnic(ComboBox c)
        {
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.Patient";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string add = reader["P_CNIC"].ToString();
                c.Items.Add(add);
            }
            conn.Close();

        }
        public void fillcombodisease(ComboBox c)
        {
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.disease";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string add = reader["diseaseName"].ToString();
                c.Items.Add(add);
            }
            conn.Close();
        }
        public int getDoctorId(string regno)
        {
            int dId = 0;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.DocRegistry";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                if (reader["docRegNo"].ToString() == regno)
                {
                    dId = int.Parse(reader["docID"].ToString());
                    break;
                }
            }
            conn.Close();
            return dId;
        }
        public string getPatName(ComboBox c)
        {
            string pname = null;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.Patient";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string patcnic = c.SelectedItem.ToString();
                if (reader["P_CNIC"].ToString() == patcnic)
                {
                    pname = reader["P_Name"].ToString();
                    break;
                }
            }
            conn.Close();
            return pname;
        }
        public int getPatientId(ComboBox c)
        {
            int pId = 0;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.Patient";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                if (reader["P_CNIC"].ToString() == c.SelectedItem.ToString())
                {
                    pId = int.Parse(reader["P_Id"].ToString());
                    break;
                }
            }
            conn.Close();
            return pId;
        }
        private int getNumberOfVisits()
        {
            int num = 0;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select count(*) as Num_visits from Examined_Patient group by Patient_Id having Patient_Id=" + getPatientId(comboBox2);
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                //if (reader["P_CNIC"].ToString() == c.SelectedItem.ToString())
                {
                    num = int.Parse(reader["Num_visits"].ToString());
                    //  break;
                }
            }
            conn.Close();
            return num;
        }
        private void fillExaminePatint()
        {
            int P_ID = getPatientId(comboBox2);
            int visit = 0;
            if (getNumberOfVisits() >= 0)
                visit = getNumberOfVisits() + 1;
            else
                visit = 1;
            string patientStatus = comboBox3.SelectedItem.ToString();
            int statusOfPatient = 8;
            if (patientStatus == "Admit Patient")
            {
                statusOfPatient = 0;
            }
            else if (patientStatus == "Regular Patient")
            {
                statusOfPatient = 1;
            }
            SqlTransaction tr;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            conn.Open();
            tr = conn.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                // string cmd = "set autocommit=0;start transaction;insert into H_User values ("+this.name+","+this.gender+","+this.age+","+this.cnic+","+this.salary+","+this.access+","+this.email+","+this.password+","+this.branch_Id+");commit;rollback";
                string cmd = "insert into Examined_Patient values (" + visit + "," + P_ID + ",CURRENT_TIMESTAMP," + statusOfPatient + ")";
                SqlCommand command = new SqlCommand(cmd, conn);
                command.Transaction = tr;
                int ex = 0;
                ex = command.ExecuteNonQuery();
                tr.Commit();
                conn.Close();
            }
            catch (Exception e)
            {
                try
                {
                    tr.Rollback();
                }
                catch (SqlException ex)
                {
                    if (tr.Connection != null)
                    {
                        Console.WriteLine("An exception of type " + ex.GetType() +
                            " was encountered while attempting to roll back the transaction.");
                    }
                }

                Console.WriteLine("An exception of type " + e.GetType() +
                    " was encountered while inserting the data.");
                Console.WriteLine("Neither record was written to database.");
            }
        }
        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            /* panel4 f4 = new addpe();
             this.Hide();
             f4.ShowDialog();*/
            panel4.Visible = true;
            panel6.Hide();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            int f = 0;
            string password = null;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.DocRegistry";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            f = 0;
            while (reader.Read())
            {
                if (reader["docRegNo"].ToString() == textBox1.Text)
                {
                    f = 1;
                    password = reader["docPassword"].ToString();
                    if (password == textBox2.Text)
                    {
                        panel6.Visible = true;
                        panel4.Hide();
                        panel7.Hide();
                        panel11.Hide();
                        break;
                    }
                    else
                    {
                        MessageBox.Show("Incorrect Password");
                        textBox1.Text = null;
                        textBox2.Text = null;
                        break;
                    }
                }
            }
            if (f == 0)
            {
                MessageBox.Show("You have not registered yet");
                textBox1.Text = null;
                textBox2.Text = null;
            }
            conn.Close();
        }
        private void bunifuTileButton3_Click(object sender, EventArgs e)
        {

        }
        private void bunifuTileButton3_Click_1(object sender, EventArgs e)
        {
            panel7.Visible = true;
            //panel7.Hide();
            panel6.Hide();
        }
        public void addDataOfOutPatient(int patId, DateTime date, int docId, int patCharges)
        {
            SqlTransaction tr;

            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);

            conn.Open();
            tr = conn.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                // string cmd = "set autocommit=0;start transaction;insert into H_User values ("+this.name+","+this.gender+","+this.age+","+this.cnic+","+this.salary+","+this.access+","+this.email+","+this.password+","+this.branch_Id+");commit;rollback";
                string cmd = "insert into OutPatient values (" + patId + ",CURRENT_TIMESTAMP," + docId + "," + patCharges + ")";
                SqlCommand command = new SqlCommand(cmd, conn);
                command.Transaction = tr;
                int ex = 0;
                ex = command.ExecuteNonQuery();
                tr.Commit();
                conn.Close();
            }
            catch (Exception e)
            {
                try
                {
                    tr.Rollback();
                }
                catch (SqlException ex)
                {
                    if (tr.Connection != null)
                    {
                        Console.WriteLine("An exception of type " + ex.GetType() +
                            " was encountered while attempting to roll back the transaction.");
                    }
                }

                Console.WriteLine("An exception of type " + e.GetType() +
                    " was encountered while inserting the data.");
                Console.WriteLine("Neither record was written to database.");
            }
        }
        public void deleteExaminePatient()
        {
            SqlTransaction tr;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);

            conn.Open();
            tr = conn.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                // string cmd = "set autocommit=0;start transaction;insert into H_User values ("+this.name+","+this.gender+","+this.age+","+this.cnic+","+this.salary+","+this.access+","+this.email+","+this.password+","+this.branch_Id+");commit;rollback";
                string cmd = "Delete from AdmittedPatient where p_id=" + getPatientId(comboBox9);
                SqlCommand command = new SqlCommand(cmd, conn);
                command.Transaction = tr;
                int ex = 0;
                ex = command.ExecuteNonQuery();
                tr.Commit();
                conn.Close();
            }
            catch (Exception e)
            {
                try
                {
                    tr.Rollback();
                }
                catch (SqlException ex)
                {
                    if (tr.Connection != null)
                    {
                        Console.WriteLine("An exception of type " + ex.GetType() +
                            " was encountered while attempting to roll back the transaction.");
                    }
                }

                Console.WriteLine("An exception of type " + e.GetType() +
                    " was encountered while inserting the data.");
                Console.WriteLine("Neither record was written to database.");
            }
        }
        public int getBed_ID(int patientId)
        {
            int bedId = 0;
            string bed = null;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.AdmittedPatient";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                if(int.Parse(reader["p_id"].ToString())== patientId)
                {
                    bedId = int.Parse(reader["bed_Id"].ToString());
                    break;
                }
            }
            conn.Close();
            return bedId;
        }
        public void changeBedStatusafterDischarge(int id)
        {
            SqlTransaction tr;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);

            conn.Open();
            tr = conn.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                string cmd = "update Bed set Bed_Status='free' where Bed_Id=" + getBed_ID(id);
                SqlCommand command = new SqlCommand(cmd, conn);
                command.Transaction = tr;
                int ex = 0;
                ex = command.ExecuteNonQuery();
                tr.Commit();
                conn.Close();
            }
            catch (Exception e)
            {
                try
                {
                    tr.Rollback();
                }
                catch (SqlException ex)
                {
                    if (tr.Connection != null)
                    {
                        Console.WriteLine("An exception of type " + ex.GetType() +
                            " was encountered while attempting to roll back the transaction.");
                    }
                }

                Console.WriteLine("An exception of type " + e.GetType() +
                    " was encountered while inserting the data.");
                Console.WriteLine("Neither record was written to database.");
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            string regNo = textBox1.Text;
            DateTime today = DateTime.Today;
            //insert into table name ('"+today+"');
            int patientID = getPatientId(comboBox9);
            int DoctorID = getDoctorId(regNo);
            int patientCharges = int.Parse(textBox6.Text);
            addDataOfOutPatient(patientID, today, DoctorID, patientCharges);
            changeBedStatusafterDischarge(patientID);
            deleteExaminePatient();
        }
        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            panel4.Hide();
            panel6.Show();
            panel7.Hide();
            panel11.Hide();
        }
        private void bunifuTileButton2_Click(object sender, EventArgs e)
        {
            panel6.Hide();
            panel4.Hide();
            panel7.Hide();
        }
        private void doctorLogin_Load(object sender, EventArgs e)
        {

        }
        private void bunifuTileButton4_Click(object sender, EventArgs e)
        {
        }
        private void bunifuTileButton5_Click(object sender, EventArgs e)
        {
        }
        private void enetrDisease(string disease)
        {
            SqlTransaction tr;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);

            conn.Open();
            tr = conn.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                // string cmd = "set autocommit=0;start transaction;insert into H_User values ("+this.name+","+this.gender+","+this.age+","+this.cnic+","+this.salary+","+this.access+","+this.email+","+this.password+","+this.branch_Id+");commit;rollback";
                string cmd = "insert into Disease values ('" + disease + "')";
                SqlCommand command = new SqlCommand(cmd, conn);
                command.Transaction = tr;
                int ex = 0;
                ex = command.ExecuteNonQuery();
                tr.Commit();
                conn.Close();
            }
            catch (Exception e)
            {
                try
                {
                    tr.Rollback();
                }
                catch (SqlException ex)
                {
                    if (tr.Connection != null)
                    {
                        Console.WriteLine("An exception of type " + ex.GetType() +
                            " was encountered while attempting to roll back the transaction.");
                    }
                }

                Console.WriteLine("An exception of type " + e.GetType() +
                    " was encountered while inserting the data.");
                Console.WriteLine("Neither record was written to database.");
            }

        }
        private int getDiseaseId(string disease)
        {
            int diseaseId = 0;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.Disease";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                if (reader["diseaseName"].ToString() == disease)
                {
                    diseaseId = int.Parse(reader["diseaseId"].ToString());
                    break;
                }
            }
            conn.Close();
            return diseaseId;
        }
        private void fillPatientDisease(string disease)
        {
            int patientId = getPatientId(comboBox2);
            int diseaseId = getDiseaseId(disease);
            //add data to database
            SqlTransaction tr;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);

            conn.Open();
            tr = conn.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                string cmd = "insert into patientdisease values (" + patientId + "," + diseaseId + ")";
                SqlCommand command = new SqlCommand(cmd, conn);
                command.Transaction = tr;
                int ex = 0;
                ex = command.ExecuteNonQuery();
                tr.Commit();
                conn.Close();
            }
            catch (Exception e)
            {
                try
                {
                    tr.Rollback();
                }
                catch (SqlException ex)
                {
                    if (tr.Connection != null)
                    {
                        Console.WriteLine("An exception of type " + ex.GetType() +
                            " was encountered while attempting to roll back the transaction.");
                    }
                }

                Console.WriteLine("An exception of type " + e.GetType() +
                    " was encountered while inserting the data.");
                Console.WriteLine("Neither record was written to database.");
            }

        }
        private void fillDoctorPatient()
        {
            string regNo = textBox1.Text;
            int patientId = getPatientId(comboBox2);
            int DoctorID = getDoctorId(regNo);
            //add data to database
            SqlTransaction tr;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);

            conn.Open();
            tr = conn.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                string cmd = "insert into doctor_examinedPatient values (" + DoctorID + "," + patientId + ")";
                SqlCommand command = new SqlCommand(cmd, conn);
                command.Transaction = tr;
                int ex = 0;
                ex = command.ExecuteNonQuery();
                tr.Commit();
                conn.Close();
            }
            catch (Exception e)
            {
                try
                {
                    tr.Rollback();
                }
                catch (SqlException ex)
                {
                    if (tr.Connection != null)
                    {
                        Console.WriteLine("An exception of type " + ex.GetType() +
                            " was encountered while attempting to roll back the transaction.");
                    }
                }

                Console.WriteLine("An exception of type " + e.GetType() +
                    " was encountered while inserting the data.");
                Console.WriteLine("Neither record was written to database.");
            }
        }
        private bool isDiseaseAlreadyPresent(string disease)
        {
            int pId = 0;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.disease";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                if (reader["diseaseName"].ToString() == disease)
                {
                    pId = 1;
                    break;
                }
            }
            conn.Close();
            if (pId == 1)
            {
                return true;
            }
            return false;
        }
        public int getBedId(ComboBox c)
        {
            int bedId = 0;
            string bed = null;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.Bed";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                bed = c.SelectedItem.ToString();
                bedId = int.Parse(reader["Bed_Id"].ToString());
                string bbb = "Bed-" + bedId;
                if (bbb == bed)
                {
                    bedId = int.Parse(reader["Bed_Id"].ToString());
                    break;
                }
            }
            conn.Close();
            return bedId;
        }
        public int getWardId(ComboBox c)
        {
            int pId = 0;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.wards";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                if (reader["WardName"].ToString() == c.SelectedItem.ToString())
                {
                    pId = int.Parse(reader["Ward_Id"].ToString());
                    break;
                }
            }
            conn.Close();
            return pId;
        }
        private void fillAdmittedPatient()
        {
            int patientId = getPatientId(comboBox2);
            int bedId = getBedId(comboBox7);
            int wardId = getWardId(comboBox5);
            DateTime admissionDate = DateTime.Today;
            //add data to database
            SqlTransaction tr;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);

            conn.Open();
            tr = conn.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                string cmd = "insert into AdmittedPatient values (" + patientId + "," + wardId + "," + bedId + ",CURRENT_TIMESTAMP)";
                SqlCommand command = new SqlCommand(cmd, conn);
                command.Transaction = tr;
                int ex = 0;
                ex = command.ExecuteNonQuery();
                tr.Commit();
                conn.Close();
            }
            catch (Exception e)
            {
                try
                {
                    tr.Rollback();
                }
                catch (SqlException ex)
                {
                    if (tr.Connection != null)
                    {
                        Console.WriteLine("An exception of type " + ex.GetType() +
                            " was encountered while attempting to roll back the transaction.");
                    }
                }

                Console.WriteLine("An exception of type " + e.GetType() +
                    " was encountered while inserting the data.");
                Console.WriteLine("Neither record was written to database.");
            }
        }
        private void changeBedStatus()
        {
            SqlTransaction tr;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);

            conn.Open();
            tr = conn.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                string cmd = "update Bed set Bed_Status='occupied' where Bed_Id=" + getBedId(comboBox7);
                SqlCommand command = new SqlCommand(cmd, conn);
                command.Transaction = tr;
                int ex = 0;
                ex = command.ExecuteNonQuery();
                tr.Commit();
                conn.Close();
            }
            catch (Exception e)
            {
                try
                {
                    tr.Rollback();
                }
                catch (SqlException ex)
                {
                    if (tr.Connection != null)
                    {
                        Console.WriteLine("An exception of type " + ex.GetType() +
                            " was encountered while attempting to roll back the transaction.");
                    }
                }

                Console.WriteLine("An exception of type " + e.GetType() +
                    " was encountered while inserting the data.");
                Console.WriteLine("Neither record was written to database.");
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            //adding examine patient 
            if (flagnew == 1)
            {
                if (flag == 0) // if only 1 disease is entered
                {
                    if (!isDiseaseAlreadyPresent(textBox4.Text))
                    {
                        enetrDisease(textBox4.Text);
                    }
                    fillPatientDisease(textBox4.Text);
                }
            }
            else if (flagold == 1)  // if combobox value is selected
            {
                string disease = comboBox4.SelectedItem.ToString();
                fillPatientDisease(disease);
            }
            if (pflagnew == 1)
            {
                if (pflag == 0)
                {
                    if (!isPriscriptionAlreadyPresent(textBox5.Text))
                    {
                        enterPriscription(textBox5.Text);
                    }
                    fillPatientPriscription(textBox5.Text);
                }
            }
            else if (pflagold == 1)
            {
                string Prescription = comboBox6.SelectedItem.ToString();
                fillPatientPriscription(Prescription);
            }
            fillExaminePatint();
            fillDoctorPatient();
            if (comboBox3.SelectedItem.ToString() == "Admit Patient")
            {
                fillAdmittedPatient();
                changeBedStatus();
                comboBox9.Items.Clear();
                fillcomboCnicOut();
            }
        }
        private void button6_Click(object sender, EventArgs e)
        {
            string disease = textBox4.Text;
            diseaselist.Add(disease);
            textBox4.Text = null;
            foreach (string s in diseaselist)
            {
                if (!isDiseaseAlreadyPresent(s))
                {
                    enetrDisease(s);
                }
                fillPatientDisease(s);
            }
            flag = 1;
        }
        private void button7_Click(object sender, EventArgs e)
        {
            string prescription = textBox5.Text;
            priscriptionList.Add(prescription);
            textBox5.Text = null;
            foreach (string s in priscriptionList)
            {
                if (!isPriscriptionAlreadyPresent(s))
                {
                    enterPriscription(s);
                }
                fillPatientPriscription(s);
            }
            pflag = 1;
        }
        private void panel11_Paint(object sender, PaintEventArgs e)
        {
            bunifuFlatButton3.Show();
        }
        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            comboBox4.Show();
            bunifuThinButton22.Hide();
            flagold = 1;
        }
        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            bunifuThinButton21.Hide();
            textBox4.Show();
            button6.Show();
            flagnew = 1;
        }
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            int index = comboBox4.FindString(textBox4.Text);
            flagnew = 0;
            flagold = 0;
            if (index < 0)
            {
                // it means that the value that u had enterd in your text box does not match to any of the combomox value
                flagnew = 1;
                return;
            }
            else
            {
                comboBox4.SelectedIndex = index;
                flagold = 1;
                return;
            }
        }
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox3.SelectedItem.ToString() == "Admit Patient")
            {
                label15.Hide();
                textBox5.Hide();
                button7.Hide();
                comboBox5.Show();
                label14.Show();
                label16.Show();
                comboBox7.Show();
                fillComboWard(comboBox5);
            }
            else if (comboBox3.SelectedItem.ToString() == "Regular Patient")
            {
                comboBox5.Hide();
                label14.Hide();
                label16.Hide();
                comboBox7.Hide();
                label15.Show();
                textBox5.Show();
                button7.Show();
            }
        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox3.Text = getPatName(comboBox2);
        }
        private bool isPriscriptionAlreadyPresent(string prescription)
        {
            int pId = 0;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.priscription";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                if (reader["prisccriptionName"].ToString() == prescription)
                {
                    pId = 1;
                    break;
                }
            }
            conn.Close();
            if (pId == 1)
            {
                return true;
            }
            return false;
        }
        private void enterPriscription(string prescriptipn)
        {
            SqlTransaction tr;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);

            conn.Open();
            tr = conn.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                // string cmd = "set autocommit=0;start transaction;insert into H_User values ("+this.name+","+this.gender+","+this.age+","+this.cnic+","+this.salary+","+this.access+","+this.email+","+this.password+","+this.branch_Id+");commit;rollback";
                string cmd = "insert into priscription values ('" + prescriptipn + "')";
                SqlCommand command = new SqlCommand(cmd, conn);
                command.Transaction = tr;
                int ex = 0;
                ex = command.ExecuteNonQuery();
                tr.Commit();
                conn.Close();
            }
            catch (Exception e)
            {
                try
                {
                    tr.Rollback();
                }
                catch (SqlException ex)
                {
                    if (tr.Connection != null)
                    {
                        Console.WriteLine("An exception of type " + ex.GetType() +
                            " was encountered while attempting to roll back the transaction.");
                    }
                }

                Console.WriteLine("An exception of type " + e.GetType() +
                    " was encountered while inserting the data.");
                Console.WriteLine("Neither record was written to database.");
            }
        }
        private int getPrescriptionId(string prescriptipn)
        {
            int prescriptipnId = 0;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.priscription";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                if (reader["prisccriptionName"].ToString() == prescriptipn)
                {
                    prescriptipnId = int.Parse(reader["priscriptionId"].ToString());
                    break;
                }
            }
            conn.Close();
            return prescriptipnId;
        }
        private void fillPatientPriscription(string prescriptipn)
        {
            int patientId = getPatientId(comboBox2);
            int prescriptionId = getPrescriptionId(prescriptipn);
            //add data to database
            SqlTransaction tr;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);

            conn.Open();
            tr = conn.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                string cmd = "insert into patient_priscription values (" + prescriptionId + "," + patientId + ")";
                SqlCommand command = new SqlCommand(cmd, conn);
                command.Transaction = tr;
                int ex = 0;
                ex = command.ExecuteNonQuery();
                tr.Commit();
                conn.Close();
            }
            catch (Exception e)
            {
                try
                {
                    tr.Rollback();
                }
                catch (SqlException ex)
                {
                    if (tr.Connection != null)
                    {
                        Console.WriteLine("An exception of type " + ex.GetType() +
                            " was encountered while attempting to roll back the transaction.");
                    }
                }

                Console.WriteLine("An exception of type " + e.GetType() +
                    " was encountered while inserting the data.");
                Console.WriteLine("Neither record was written to database.");
            }

        }
        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            int index = comboBox6.FindString(textBox5.Text);
            pflagnew = 0;
            pflagold = 0;
            if (index < 0)
            {
                // it means that the value that u had enterd in your text box does not match to any of the combomox value
                pflagnew = 1;
                return;
            }
            else
            {
                comboBox6.SelectedIndex = index;
                pflagold = 1;
                return;
            }
        }
        private void bunifuTileButton3_Click_2(object sender, EventArgs e)
        {
            panel4.Hide();
            panel6.Hide();
            panel7.Show();
            panel11.Hide();
            comboBox9.Items.Clear();
            fillcomboCnicOut();
        }
        private void label28_Click(object sender, EventArgs e)
        {

        }
        private int getPatientCharges()
        {
            int patientCharges = 0;
            string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
            SqlConnection conn = new SqlConnection(conUrl);
            string cmd = "select * from dbo.Bills";
            SqlCommand command = new SqlCommand(cmd, conn);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                if (int.Parse(reader["Patient_Id"].ToString()) == getPatientId(comboBox9))
                {
                    patientCharges = int.Parse(reader["Total_Bill"].ToString());
                    break;
                }
            }
            conn.Close();
            return patientCharges;
        }
        private void comboBox9_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox8.Text = getPatName(comboBox9);
            textBox6.Text = getPatientCharges().ToString();
        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {
            bunifuFlatButton3.Show();
        }

        private void bunifuTileButton6_Click(object sender, EventArgs e)
        {
            panel4.Hide();
            panel6.Hide();
            panel7.Hide();
            panel11.Show();
        }

        private void bunifuFlatButton1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {
            bunifuFlatButton3.Hide();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
            bunifuFlatButton3.Hide();
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox7.Items.Clear();
            fillComboBed();
        }
    }
}
