﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBMS
{
    public partial class Branch : Form
    {
        public Branch()
        {
            InitializeComponent();
            textBox1.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // defining connecction URL
            string conURL = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";

            //establishing connection
            SqlConnection conn = new SqlConnection(conURL);

            //opening connection
            conn.Open();

            //inserting values in LibraryItem table
            String add3 = "INSERT into Hospital VALUES ('" + textBox1.Text + "')";
            SqlCommand command1 = new SqlCommand(add3, conn);
            int ex = 0;
            ex=command1.ExecuteNonQuery();
            if(ex==1)
            {
                MessageBox.Show("Branch Added!");
            }
            else
            {
                MessageBox.Show("u enetred Duplicate address");
            }
            //inserting values in class
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = null;
            textBox1.Text = comboBox3.SelectedItem.ToString();
        }
    }
}
