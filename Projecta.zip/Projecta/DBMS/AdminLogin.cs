﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBMS
{
    public partial class AdminLogin : Form
    {
        public AdminLogin()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "2015ce64@student.uet.edu.pk"&&textBox2.Text=="12345")
            {
                AdminPanel f4 = new AdminPanel();
                this.Hide();
                f4.ShowDialog();
            }
            else
            {
                int f = 0;
                string password = null;
                string conUrl = "Data Source=DESKTOP-0DGR9RA; Initial Catalog = Hospital Management System; Integrated Security = True";
                SqlConnection conn = new SqlConnection(conUrl);
                string cmd = "select * from dbo.H_User";
                SqlCommand command = new SqlCommand(cmd, conn);
                conn.Open();
                SqlDataReader reader = command.ExecuteReader();
                f = 0;
                while (reader.Read())
                {
                    if (reader["U_LoginId"].ToString() == textBox1.Text && int.Parse(reader["Access_Id"].ToString()) == 1)
                    {
                        f = 1;
                        password = reader["U_Password"].ToString();
                        if (password == textBox2.Text)
                        {
                            AdminPanel f4 = new AdminPanel();
                            this.Hide();
                            f4.ShowDialog();
                            break;
                        }
                        else
                        {
                            MessageBox.Show("Incorrect Password");
                            textBox1.Text = null;
                            textBox2.Text = null;
                            break;
                        }
                    }
                }
                if (f == 0)
                {
                    MessageBox.Show("You have not registered yet");
                    textBox1.Text = null;
                    textBox2.Text = null;
                }
                conn.Close();
            }
        }
    

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            //MDIParent1 f5 = new MDIParent1();
            this.Hide();
            //f5.ShowDialog();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            addperson f5 = new addperson();
            this.Hide();
            f5.ShowDialog();
        }
    }
}
